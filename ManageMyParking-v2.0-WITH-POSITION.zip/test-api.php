<?php
/**
 * API Error Tester
 * Visit: https://myparkingmgr.com/test-api.php
 * This will show the ACTUAL error from the properties API
 */

// Enable ALL error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Use the app's session configuration
require_once __DIR__ . '/includes/session.php';
Session::start();

echo "<!DOCTYPE html><html><head><title>API Test</title>";
echo "<style>body{font-family:monospace;background:#1a1a1a;color:#0f0;padding:20px;}";
echo "h2{color:#0ff;border-bottom:2px solid #0ff;padding-bottom:10px;}";
echo ".error{color:#f00;font-weight:bold;}.success{color:#0f0;font-weight:bold;}";
echo "pre{background:#2a2a2a;padding:15px;border:1px solid #444;overflow-x:auto;}</style></head><body>";

echo "<h1>🧪 API Error Test</h1>";

// Check session
echo "<h2>📋 Session Status</h2>";
if (Session::isAuthenticated()) {
    $user = Session::user();
    echo "<p class='success'>✅ Logged in as: " . htmlspecialchars($user['username']) . "</p>";
    echo "<p>Role: " . htmlspecialchars($user['role']) . "</p>";
    echo "<p>User ID: " . htmlspecialchars($user['id']) . "</p>";
} else {
    echo "<p class='error'>❌ NOT LOGGED IN - Please login first, then visit this page</p>";
    echo "<p>Go to <a href='/'>home page</a> to login</p>";
    exit;
}

// Now test the properties API directly
echo "<h2>🔍 Testing /api/properties</h2>";

try {
    require_once __DIR__ . '/includes/database.php';
    
    $db = Database::getInstance();
    $user = Session::user();
    
    echo "<p class='success'>✅ Database connected</p>";
    
    // Test the exact query from properties.php
    $role = strtolower($user['role']);
    
    if ($role === 'admin' || $role === 'operator') {
        echo "<p>Running admin query...</p>";
        $stmt = $db->prepare("
            SELECT id, name, address, custom_ticket_text, created_at 
            FROM properties 
            ORDER BY name ASC
        ");
        $stmt->execute();
    } else {
        echo "<p>Running user query...</p>";
        $stmt = $db->prepare("
            SELECT p.id, p.name, p.address, p.custom_ticket_text, p.created_at
            FROM properties p
            INNER JOIN user_assigned_properties uap ON p.id = uap.property_id
            WHERE uap.user_id = ?
            ORDER BY p.name ASC
        ");
        $stmt->execute([$user['id']]);
    }
    
    $properties = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "<p class='success'>✅ Properties query successful: " . count($properties) . " found</p>";
    
    // Now test property_contacts query
    echo "<p>Testing property_contacts query...</p>";
    foreach ($properties as &$property) {
        $contactStmt = $db->prepare("
            SELECT name, phone, email, position
            FROM property_contacts 
            WHERE property_id = ? 
            ORDER BY position ASC
        ");
        $contactStmt->execute([$property['id']]);
        $property['contacts'] = $contactStmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    echo "<p class='success'>✅ Property contacts query successful</p>";
    
    // Show the result
    echo "<h2>📊 Result</h2>";
    echo "<pre>" . json_encode(['properties' => $properties], JSON_PRETTY_PRINT) . "</pre>";
    
    echo "<p class='success'><strong>✅ NO ERRORS - API should work!</strong></p>";
    
} catch (PDOException $e) {
    echo "<p class='error'>❌ DATABASE ERROR:</p>";
    echo "<pre>" . htmlspecialchars($e->getMessage()) . "</pre>";
    echo "<pre>File: " . htmlspecialchars($e->getFile()) . ":" . $e->getLine() . "</pre>";
} catch (Exception $e) {
    echo "<p class='error'>❌ GENERAL ERROR:</p>";
    echo "<pre>" . htmlspecialchars($e->getMessage()) . "</pre>";
    echo "<pre>File: " . htmlspecialchars($e->getFile()) . ":" . $e->getLine() . "</pre>";
}

echo "<hr><p><strong>⚠️ DELETE THIS FILE after testing (security risk)</strong></p>";
echo "</body></html>";
