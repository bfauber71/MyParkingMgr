<?php
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/helpers.php';

Session::start();

// Require authentication and create/delete permission for properties
requirePermission(MODULE_PROPERTIES, ACTION_CREATE_DELETE);

$user = Session::user();

$input = json_decode(file_get_contents('php://input'), true);

$name = trim($input['name'] ?? '');
$address = trim($input['address'] ?? '');
$contacts = $input['contacts'] ?? [];

if (empty($name)) {
    http_response_code(400);
    echo json_encode(['error' => 'Property name is required']);
    exit;
}

if (empty($contacts) || !is_array($contacts)) {
    http_response_code(400);
    echo json_encode(['error' => 'At least one contact is required']);
    exit;
}

if (count($contacts) > 3) {
    http_response_code(400);
    echo json_encode(['error' => 'Maximum 3 contacts allowed']);
    exit;
}

foreach ($contacts as $idx => $contact) {
    $contactName = trim($contact['name'] ?? '');
    if (empty($contactName)) {
        http_response_code(400);
        echo json_encode(['error' => "Contact " . ($idx + 1) . " name is required"]);
        exit;
    }
}

$db = Database::getInstance();

try {
    $db->beginTransaction();
    
    $stmt = $db->prepare("SELECT id FROM properties WHERE name = ?");
    $stmt->execute([$name]);
    if ($stmt->fetch()) {
        $db->rollBack();
        http_response_code(400);
        echo json_encode(['error' => 'Property name already exists']);
        exit;
    }
    
    $propertyId = $db->query("SELECT UUID()")->fetchColumn();
    
    $stmt = $db->prepare("
        INSERT INTO properties (id, name, address, created_at, updated_at)
        VALUES (?, ?, ?, NOW(), NOW())
    ");
    $stmt->execute([$propertyId, $name, $address]);
    
    $contactStmt = $db->prepare("
        INSERT INTO property_contacts (property_id, name, phone, email, position, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, NOW(), NOW())
    ");
    
    foreach ($contacts as $position => $contact) {
        $contactName = trim($contact['name'] ?? '');
        $contactPhone = trim($contact['phone'] ?? '');
        $contactEmail = trim($contact['email'] ?? '');
        
        $contactStmt->execute([
            $propertyId,
            $contactName,
            $contactPhone ?: null,
            $contactEmail ?: null,
            $position
        ]);
    }
    
    $db->commit();
    
    auditLog('create_property', 'properties', $propertyId, "Created property: $name with " . count($contacts) . " contact(s)");
    
    echo json_encode([
        'success' => true,
        'id' => $propertyId,
        'message' => 'Property created successfully'
    ]);
} catch (PDOException $e) {
    $db->rollBack();
    error_log("Property Create Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
