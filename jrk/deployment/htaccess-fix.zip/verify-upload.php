<?php
// Ultra-simple test file
echo "Files uploaded successfully!";
echo "\nPHP Version: " . PHP_VERSION;
