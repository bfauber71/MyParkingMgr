# URGENT: Session Fix for Fresh Installs

## Problem
Fresh installs show NO vehicles or violations because sessions don't work over HTTP.

## Root Cause
The setup wizard generates config.php with `'secure' => true`, which requires HTTPS. 
When accessed over HTTP, session cookies are rejected by the browser.

## Symptoms
- Login appears successful
- Immediately after login, no data shows
- Vehicles tab: empty
- Violations tab: empty
- No error messages

## Fix for Existing Installations

If you already ran the setup wizard and have this issue:

1. **Edit your config.php file**
2. **Find this section:**
   ```php
   'session' => [
       'name' => 'myparkingmanager_session',
       'lifetime' => 1440,
       'secure' => true,  // <-- THIS IS THE PROBLEM
       'httponly' => true,
   ],
   ```

3. **Change `true` to `'auto'`:**
   ```php
   'session' => [
       'name' => 'myparkingmanager_session',
       'lifetime' => 1440,
       'secure' => 'auto',  // <-- FIXED
       'httponly' => true,
   ],
   ```

4. **Save the file and reload the page**

## For New Installations
The fixed setup-wizard.php now generates the correct config automatically.

## Version
Fixed in: v2.3.6 (October 27, 2025)
