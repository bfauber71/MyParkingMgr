================================================================
MyParkingManager v2.3.6 - Full Installation Package
================================================================

CRITICAL SECURITY REQUIREMENT: HTTPS IS MANDATORY
--------------------------------------------------
This application requires HTTPS (SSL certificate) to function.
See HTTPS-REQUIRED.txt for detailed instructions.

Quick Setup Guide:
------------------
1. Enable HTTPS/SSL on your server FIRST
2. Upload all files to your web server
3. Create MySQL database and import sql/install.sql
4. Visit https://yourdomain.com/setup-wizard.php
5. Follow the wizard (it will warn if HTTPS is not detected)
6. Delete setup-wizard.php after completion
7. Login and configure your properties

System Requirements:
--------------------
✓ HTTPS/SSL Certificate (REQUIRED)
✓ PHP 7.4+ (PHP 8.0+ recommended)
✓ MySQL 5.7+ or MariaDB 10.2+
✓ Apache with mod_rewrite
✓ Shared hosting compatible

Files Included:
---------------
- api/ - API endpoints
- assets/ - Frontend JavaScript and CSS
- includes/ - PHP core classes
- sql/ - Database installation scripts
- admin/ - Admin utilities
- setup-wizard.php - Installation wizard
- index.html - Main application
- HTTPS-REQUIRED.txt - Security documentation
- config-sample.php - Configuration template

Security Features:
------------------
✓ Secure session cookies (requires HTTPS)
✓ CSRF protection
✓ SQL injection prevention
✓ Password hashing (bcrypt)
✓ Role-based access control
✓ Audit logging
✓ Login attempt limiting

Support Files:
--------------
- HTTPS-REQUIRED.txt - How to enable HTTPS
- sql/install.sql - Complete database schema

Version: 2.3.6
Release Date: October 27, 2025
Security: Production-Ready with HTTPS
================================================================
