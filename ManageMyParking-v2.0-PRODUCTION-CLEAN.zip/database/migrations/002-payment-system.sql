-- ManageMyParking v2.0 Payment System Migration
-- Run this after the base schema is installed

-- Payment processor configuration (per property)
CREATE TABLE IF NOT EXISTS payment_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    property_id INT NOT NULL,
    processor_type ENUM('stripe', 'square', 'paypal', 'disabled') DEFAULT 'disabled',
    api_key_encrypted TEXT,
    api_secret_encrypted TEXT,
    webhook_secret_encrypted TEXT,
    publishable_key VARCHAR(255),
    is_live_mode BOOLEAN DEFAULT FALSE,
    enable_qr_codes BOOLEAN DEFAULT TRUE,
    enable_online_payments BOOLEAN DEFAULT TRUE,
    payment_description_template VARCHAR(500) DEFAULT 'Parking Violation - Ticket #{ticket_id}',
    success_redirect_url VARCHAR(500),
    failure_redirect_url VARCHAR(500),
    allow_cash_payments BOOLEAN DEFAULT TRUE,
    allow_check_payments BOOLEAN DEFAULT TRUE,
    allow_manual_card BOOLEAN DEFAULT TRUE,
    require_check_number BOOLEAN DEFAULT TRUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (property_id) REFERENCES properties(id) ON DELETE CASCADE,
    UNIQUE KEY unique_property_settings (property_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Payment records
CREATE TABLE IF NOT EXISTS ticket_payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ticket_id INT NOT NULL,
    payment_method ENUM('cash', 'check', 'card_manual', 'stripe_online', 'square_online', 'paypal_online') NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    check_number VARCHAR(50) NULL,
    transaction_id VARCHAR(255) NULL,
    payment_link_url TEXT NULL,
    qr_code_path VARCHAR(255) NULL,
    status ENUM('pending', 'completed', 'failed', 'refunded') DEFAULT 'completed',
    recorded_by_user_id INT NOT NULL,
    notes TEXT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (ticket_id) REFERENCES violation_tickets(id) ON DELETE CASCADE,
    FOREIGN KEY (recorded_by_user_id) REFERENCES users(id),
    INDEX idx_ticket_id (ticket_id),
    INDEX idx_payment_date (payment_date),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Add payment tracking fields to violation_tickets
ALTER TABLE violation_tickets 
ADD COLUMN IF NOT EXISTS payment_status ENUM('unpaid', 'partial', 'paid') DEFAULT 'unpaid',
ADD COLUMN IF NOT EXISTS amount_paid DECIMAL(10,2) DEFAULT 0.00,
ADD COLUMN IF NOT EXISTS payment_link_id VARCHAR(255) NULL,
ADD COLUMN IF NOT EXISTS qr_code_generated_at DATETIME NULL,
ADD INDEX IF NOT EXISTS idx_payment_status (payment_status);

-- Create QR codes directory reference table (optional - for tracking generated QR codes)
CREATE TABLE IF NOT EXISTS qr_codes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ticket_id INT NOT NULL,
    file_path VARCHAR(255) NOT NULL,
    payment_url TEXT NOT NULL,
    generated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (ticket_id) REFERENCES violation_tickets(id) ON DELETE CASCADE,
    INDEX idx_ticket_id (ticket_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert default payment settings for existing properties
INSERT IGNORE INTO payment_settings (property_id, processor_type, enable_qr_codes, enable_online_payments)
SELECT id, 'disabled', TRUE, FALSE FROM properties;
