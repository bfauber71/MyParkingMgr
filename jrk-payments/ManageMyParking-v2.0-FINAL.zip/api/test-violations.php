<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../includes/database.php';

header('Content-Type: application/json');

try {
    $db = Database::getInstance();
    
    // Test simple query
    $result = $db->query("SELECT COUNT(*) as cnt FROM violation_tickets")->fetch(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'ticket_count' => $result['cnt'],
        'message' => 'Database connection OK'
    ], JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'trace' => $e->getTraceAsString()
    ], JSON_PRETTY_PRINT);
}
