<?php
/**
 * Printer Settings API Error Tester
 * Visit: https://myparkingmgr.com/test-printer-api.php
 * This will show the ACTUAL error from the printer-settings API
 */

// Enable ALL error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Use the app's session configuration
require_once __DIR__ . '/includes/session.php';
Session::start();

echo "<!DOCTYPE html><html><head><title>Printer API Test</title>";
echo "<style>body{font-family:monospace;background:#1a1a1a;color:#0f0;padding:20px;}";
echo "h2{color:#0ff;border-bottom:2px solid #0ff;padding-bottom:10px;}";
echo ".error{color:#f00;font-weight:bold;}.success{color:#0f0;font-weight:bold;}";
echo ".warning{color:#fa0;font-weight:bold;}";
echo "pre{background:#2a2a2a;padding:15px;border:1px solid #444;overflow-x:auto;white-space:pre-wrap;}";
echo "table{border-collapse:collapse;margin:10px 0;background:#2a2a2a;}";
echo "th,td{border:1px solid #444;padding:8px 12px;text-align:left;}";
echo "th{background:#333;color:#ff0;}</style></head><body>";

echo "<h1>🖨️ Printer Settings API Test</h1>";

// Check session
echo "<h2>📋 Session Status</h2>";
if (Session::isAuthenticated()) {
    $user = Session::user();
    echo "<p class='success'>✅ Logged in as: " . htmlspecialchars($user['username']) . "</p>";
    echo "<p>Role: " . htmlspecialchars($user['role']) . "</p>";
    echo "<p>User ID: " . htmlspecialchars($user['id']) . "</p>";
} else {
    echo "<p class='error'>❌ NOT LOGGED IN - Please login first, then visit this page</p>";
    echo "<p>Go to <a href='/'>home page</a> to login</p>";
    exit;
}

// Now test the printer-settings API
echo "<h2>🔍 Testing /api/printer-settings</h2>";

try {
    require_once __DIR__ . '/includes/database.php';
    
    $db = Database::getInstance();
    echo "<p class='success'>✅ Database connected</p>";
    
    // Check if printer_settings table exists
    echo "<h3>📊 Checking printer_settings Table</h3>";
    $tableCheck = $db->query("SHOW TABLES LIKE 'printer_settings'")->fetch();
    
    if ($tableCheck) {
        echo "<p class='success'>✅ printer_settings table exists</p>";
        
        // Show table structure
        echo "<h3>🏗️ Table Structure</h3>";
        $columns = $db->query("DESCRIBE printer_settings")->fetchAll(PDO::FETCH_ASSOC);
        echo "<table><tr><th>Column</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr>";
        foreach ($columns as $col) {
            echo "<tr>";
            echo "<td>{$col['Field']}</td>";
            echo "<td>{$col['Type']}</td>";
            echo "<td>{$col['Null']}</td>";
            echo "<td>{$col['Key']}</td>";
            echo "<td>" . ($col['Default'] ?? 'NULL') . "</td>";
            echo "</tr>";
        }
        echo "</table>";
        
        // Try to query printer settings
        echo "<h3>🔍 Querying Printer Settings</h3>";
        $stmt = $db->query("SELECT * FROM printer_settings ORDER BY id DESC LIMIT 1");
        $settings = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($settings) {
            echo "<p class='success'>✅ Settings found in database</p>";
            echo "<pre>" . json_encode($settings, JSON_PRETTY_PRINT) . "</pre>";
        } else {
            echo "<p class='warning'>⚠️ No printer settings found in database (empty table)</p>";
            echo "<p>This is normal for a fresh install - default settings will be returned</p>";
        }
        
        // Test the actual GET request logic
        echo "<h3>🧪 Testing GET Request Logic</h3>";
        
        if (!$settings) {
            echo "<p>No settings in DB - should return defaults:</p>";
            $defaultSettings = [
                'printer_name' => '',
                'printer_ip' => '',
                'print_method' => 'download',
                'timezone' => 'America/New_York'
            ];
            echo "<pre>" . json_encode($defaultSettings, JSON_PRETTY_PRINT) . "</pre>";
        }
        
        echo "<p class='success'><strong>✅ NO ERRORS - Printer Settings API should work!</strong></p>";
        
    } else {
        echo "<p class='error'>❌ printer_settings table does NOT exist!</p>";
        echo "<p>You need to create this table. Run this SQL:</p>";
        echo "<pre>CREATE TABLE IF NOT EXISTS printer_settings (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    printer_name VARCHAR(255),
    printer_ip VARCHAR(45),
    print_method ENUM('download', 'network') DEFAULT 'download',
    timezone VARCHAR(100) DEFAULT 'America/New_York',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;</pre>";
    }
    
} catch (PDOException $e) {
    echo "<p class='error'>❌ DATABASE ERROR:</p>";
    echo "<pre>" . htmlspecialchars($e->getMessage()) . "</pre>";
    echo "<pre>File: " . htmlspecialchars($e->getFile()) . ":" . $e->getLine() . "</pre>";
    echo "<pre>Code: " . $e->getCode() . "</pre>";
} catch (Exception $e) {
    echo "<p class='error'>❌ GENERAL ERROR:</p>";
    echo "<pre>" . htmlspecialchars($e->getMessage()) . "</pre>";
    echo "<pre>File: " . htmlspecialchars($e->getFile()) . ":" . $e->getLine() . "</pre>";
}

echo "<hr><p><strong>⚠️ DELETE THIS FILE after testing (security risk)</strong></p>";
echo "<p>File location: <code>/test-printer-api.php</code></p>";
echo "</body></html>";
