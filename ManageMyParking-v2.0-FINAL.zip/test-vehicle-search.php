<?php
/**
 * Vehicle Search API Error Tester
 * Visit: https://myparkingmgr.com/test-vehicle-search.php
 * This will show the ACTUAL error from the vehicle search API
 */

// Enable ALL error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Use the app's session configuration
require_once __DIR__ . '/includes/session.php';
Session::start();

echo "<!DOCTYPE html><html><head><title>Vehicle Search Test</title>";
echo "<style>body{font-family:monospace;background:#1a1a1a;color:#0f0;padding:20px;}";
echo "h2{color:#0ff;border-bottom:2px solid #0ff;padding-bottom:10px;}";
echo ".error{color:#f00;font-weight:bold;}.success{color:#0f0;font-weight:bold;}";
echo ".warning{color:#fa0;font-weight:bold;}";
echo "pre{background:#2a2a2a;padding:15px;border:1px solid #444;overflow-x:auto;white-space:pre-wrap;}";
echo "table{border-collapse:collapse;margin:10px 0;background:#2a2a2a;}";
echo "th,td{border:1px solid #444;padding:8px 12px;text-align:left;}";
echo "th{background:#333;color:#ff0;}</style></head><body>";

echo "<h1>🚗 Vehicle Search API Test</h1>";

// Check session
echo "<h2>📋 Session Status</h2>";
if (Session::isAuthenticated()) {
    $user = Session::user();
    echo "<p class='success'>✅ Logged in as: " . htmlspecialchars($user['username']) . "</p>";
    echo "<p>Role: " . htmlspecialchars($user['role']) . "</p>";
    echo "<p>User ID: " . htmlspecialchars($user['id']) . "</p>";
} else {
    echo "<p class='error'>❌ NOT LOGGED IN - Please login first, then visit this page</p>";
    echo "<p>Go to <a href='/'>home page</a> to login</p>";
    exit;
}

// Check vehicles table
echo "<h2>🔍 Checking vehicles Table</h2>";

try {
    require_once __DIR__ . '/includes/database.php';
    
    $db = Database::getInstance();
    echo "<p class='success'>✅ Database connected</p>";
    
    // Check if vehicles table exists
    $tableCheck = $db->query("SHOW TABLES LIKE 'vehicles'")->fetch();
    
    if ($tableCheck) {
        echo "<p class='success'>✅ vehicles table exists</p>";
        
        // Show table structure
        echo "<h3>🏗️ Table Structure</h3>";
        $columns = $db->query("DESCRIBE vehicles")->fetchAll(PDO::FETCH_ASSOC);
        echo "<table><tr><th>Column</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr>";
        foreach ($columns as $col) {
            echo "<tr>";
            echo "<td>{$col['Field']}</td>";
            echo "<td>{$col['Type']}</td>";
            echo "<td>{$col['Null']}</td>";
            echo "<td>{$col['Key']}</td>";
            echo "<td>" . ($col['Default'] ?? 'NULL') . "</td>";
            echo "</tr>";
        }
        echo "</table>";
        
        // Count vehicles
        $countStmt = $db->query("SELECT COUNT(*) as count FROM vehicles");
        $count = $countStmt->fetch(PDO::FETCH_ASSOC)['count'];
        echo "<p>Total vehicles in database: <strong>$count</strong></p>";
        
        // Test a simple search query
        echo "<h3>🧪 Testing Search Query</h3>";
        
        $role = strtolower($user['role']);
        $search = ''; // Empty search to get all
        
        if ($role === 'admin' || $role === 'operator') {
            echo "<p>Running admin/operator query (all vehicles)...</p>";
            $sql = "SELECT v.*, p.name as property_name 
                    FROM vehicles v 
                    LEFT JOIN properties p ON v.property_id = p.id 
                    ORDER BY v.created_at DESC 
                    LIMIT 10";
            $stmt = $db->prepare($sql);
            $stmt->execute();
        } else {
            echo "<p>Running regular user query (assigned properties only)...</p>";
            $sql = "SELECT v.*, p.name as property_name 
                    FROM vehicles v 
                    LEFT JOIN properties p ON v.property_id = p.id 
                    INNER JOIN user_assigned_properties uap ON v.property_id = uap.property_id 
                    WHERE uap.user_id = ? 
                    ORDER BY v.created_at DESC 
                    LIMIT 10";
            $stmt = $db->prepare($sql);
            $stmt->execute([$user['id']]);
        }
        
        $vehicles = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "<p class='success'>✅ Query successful! Found " . count($vehicles) . " vehicles</p>";
        
        if (count($vehicles) > 0) {
            echo "<h3>📊 Sample Results</h3>";
            echo "<pre>" . json_encode(array_slice($vehicles, 0, 3), JSON_PRETTY_PRINT) . "</pre>";
        } else {
            echo "<p class='warning'>⚠️ No vehicles found in database</p>";
        }
        
        echo "<p class='success'><strong>✅ NO ERRORS - Vehicle Search API should work!</strong></p>";
        
    } else {
        echo "<p class='error'>❌ vehicles table does NOT exist!</p>";
    }
    
} catch (PDOException $e) {
    echo "<p class='error'>❌ DATABASE ERROR:</p>";
    echo "<pre>" . htmlspecialchars($e->getMessage()) . "</pre>";
    echo "<pre>File: " . htmlspecialchars($e->getFile()) . ":" . $e->getLine() . "</pre>";
    echo "<pre>Code: " . $e->getCode() . "</pre>";
    
    // Check for common issues
    if (strpos($e->getMessage(), 'Column') !== false && strpos($e->getMessage(), 'not found') !== false) {
        echo "<h3 class='error'>🔍 Likely Issue: Missing Column</h3>";
        echo "<p>The query is looking for a column that doesn't exist in your vehicles table.</p>";
    } elseif (strpos($e->getMessage(), 'property_id') !== false) {
        echo "<h3 class='error'>🔍 Likely Issue: property_id Column</h3>";
        echo "<p>The vehicles table might be missing the property_id column.</p>";
        echo "<p>Run this SQL to add it:</p>";
        echo "<pre>ALTER TABLE vehicles ADD COLUMN property_id VARCHAR(36) AFTER id;</pre>";
    }
} catch (Exception $e) {
    echo "<p class='error'>❌ GENERAL ERROR:</p>";
    echo "<pre>" . htmlspecialchars($e->getMessage()) . "</pre>";
    echo "<pre>File: " . htmlspecialchars($e->getFile()) . ":" . $e->getLine() . "</pre>";
}

echo "<hr><p><strong>⚠️ DELETE THIS FILE after testing (security risk)</strong></p>";
echo "<p>File location: <code>/test-vehicle-search.php</code></p>";
echo "</body></html>";
